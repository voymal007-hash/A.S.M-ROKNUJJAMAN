/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "f82f9e4ba89130d19f0de0cf54a7a188"
  }, {
    "url": "pwa-512x512.png",
    "revision": "d3ff05f7b3a071381ec714a111809ce4"
  }, {
    "url": "pwa-192x192.png",
    "revision": "62cf26bad14e8eaeb11b70c89604e314"
  }, {
    "url": "index.html",
    "revision": "6812383ea6904a4810cca8e0c2d02f84"
  }, {
    "url": "icon.svg",
    "revision": "704d74370516c2efcef63ae4b762bf64"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b318f7f5534ce2574e6a83279215e6e4"
  }, {
    "url": "Land_Ledger_Mobile_App.html",
    "revision": "a0435258df63012c9138583a10897904"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-Dqi2FDni.js",
    "revision": null
  }, {
    "url": "assets/index-5jQ1u_8Q.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b318f7f5534ce2574e6a83279215e6e4"
  }, {
    "url": "icon.svg",
    "revision": "704d74370516c2efcef63ae4b762bf64"
  }, {
    "url": "pwa-192x192.png",
    "revision": "62cf26bad14e8eaeb11b70c89604e314"
  }, {
    "url": "pwa-512x512.png",
    "revision": "d3ff05f7b3a071381ec714a111809ce4"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f82f9e4ba89130d19f0de0cf54a7a188"
  }, {
    "url": "manifest.webmanifest",
    "revision": "c59aebb19d652ada2509883ffe2808f3"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
